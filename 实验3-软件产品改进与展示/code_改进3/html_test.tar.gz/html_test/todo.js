ngApp = angular.module('todoApp', []);

ngApp
    .controller('TestController', function ($scope,$http,$rootScope) {



    //调度api获得处理的数据
    $scope.getData = function (url) {
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            async: false
            ,
            success: function (data) {
                alert("访问成功，返回json数据");
                console.log(data);
            },
            error: function (error) {
                if( url == "" )
                    alert("目标url为空串");
                else if( url == null)
                    alert("目标url为空");
                else
                    alert("访问错误url");
                console.log(error);
            }
        });
    };

    //获得本api的数据
    var getApi = function (target) {
        $http.get(target).then(function (response) {
            $scope.urls = response.data;
            console.log($scope.urls);
        });
    };

    getApi("config.json");

    $scope.urls = {

    };

    getApi("config.json");


});

