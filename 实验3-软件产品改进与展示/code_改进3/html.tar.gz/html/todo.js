ngApp = angular.module('todoApp', []);

ngApp
    .controller('PictureController01', function ($scope,$http,$rootScope) {
    /*变量集合*/
    var target = 'config.json';
    self.url = "";
    $scope.mapArray = ['一','二','三','四','五','六','七','八','九','十'];

    /*方法集合*/
    //数据格式处理
    var dealData = function (data) {
        order =[];
        co = [];
        for( i in data) {
            order.push(data[i].order);
            co.push(data[i].count);
        }
        result= {};
        result['order'] = order;
        result['co'] = co;
        return result;
    };

    //设置图片属性
    var setPicture_01 = function ( a,b ) {
        var myChart = echarts.init(document.getElementById('grah_01'));
        // 指定图表的配置项和数据

        var option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                },
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'value',
                boundaryGap: [0, 0.01]
            },
            yAxis: {
                type: 'category',
                data: a
            },
            series: [
                {
                    type: 'bar',
                    data: b
                }
            ]
        };

        myChart.setOption(option);
    };

    //调度api获得处理的数据
    var getData = function (url) {
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            async: false
            ,
            success: function (data) {
                $scope.data = data;
                result = dealData(data);
                setPicture_01(result.order,result.co);

            },
            error: function () {
                console.log('api_error');
            }
        });
    };

    //获得本api的数据
    var getApi = function (target) {
        $http.get(target).then(function (response) {
            var urls = response.data;
            self.url = urls['api_01'];
            getData(self.url);
        });
    };

    //监听按钮
    $scope.$watch('aaa', function (newValue, oldValue) {
        if( $rootScope.aaa !=0) {
            getApi(target);
        }
    });

    //判断字符串长度
    $scope.judgeStr = function (str,len) {
        if( str.length > len )
            return str.slice(0,len)+'...';
        return str
    };

    /*执行阶段*/
    //测试




});

ngApp
    .controller('PictureController02', function ($scope,$http,$rootScope) {

    /*变量集合*/
    var target = 'config.json';
    self.url = "";
    $scope.mapArray = ['一','二','三','四','五','六','七','八','九','十'];

    /*方法集合*/
    //设置图片内容
    var setPicture_02 = function (arg_1,arg_2) {
        var myChart = echarts.init(document.getElementById('grah_02'));
        // 指定图表的配置项和数据
        var option = {
            color: ['#3398DB'],
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    data : arg_1,
                    axisTick: {
                        alignWithLabel: true
                    }
                }
            ],
            yAxis : [
                {

                    axisTick: {
                        alignWithLabel: true
                    }
                }
            ],
            series : [
                {
                    // name:'直接访问',
                    type:'bar',
                    barWidth: '40%',
                    // data:[1, 3, 2, 3, 4, 2, 1,3,3,2,3,2]
                    data:arg_2
                },

            ],
            label: {
                normal: {
                    show: true,
                    position: 'top',
                    formatter: '{c}'
                }
            },
            itemStyle: {
                normal: {

                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(17, 168,171, 1)'
                    }, {
                        offset: 1,
                        color: 'rgba(17, 168,171, 0.1)'
                    }]),
                    shadowColor: 'rgba(0, 0, 0, 0.1)',
                    shadowBlur: 10
                }
            }
        };

        myChart.setOption(option);
    };

    //划分获取的数据
    var divisionData = function (data) {
        arg_1 = [];
        arg_2 = [];
        for( i in data) {
            arg_2.push(data[i].order);
            arg_1.push(data[i].count);
        }
        result = {};
        result['arg_1'] =arg_1;
        result['arg_2'] =arg_2;
        return result;
    };

    //调度api获得数据
    var getData = function (url) {
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            async: false
            ,
            success: function (data) {
                result = divisionData(data);
                $scope.data = data;
                setPicture_02(result.arg_2,result.arg_1);
            },
            error: function () {
                console.log('api_error');
            }
        });
    };

    //获得本api的数据
    var getApi_02 = function (target) {
        $http.get(target).then(function (response) {
            var urls = response.data;
            self.url = urls['api_02'];
            getData( self.url );
        });
    };

    //设置字符串处理系统
    $scope.judgeStr = function (str,len) {
        if( str.length > len )
            return str.slice(0,len)+'...';
        return str
    };

    $scope.$watch('aaa', function (newValue, oldValue) {
        if( $rootScope.aaa !=0) {
            getApi_02(target);
        }
    });

});

ngApp
    .controller('PictureController03', function ($scope,$http,$rootScope) {

    /*变量集合*/
    var target = 'config.json';
    self.url = "";
    $scope.mapArray = ['一','二','三','四','五','六','七','八','九','十'];
    /*方法集合*/
    //设置图片内容
    var setPicture_03 = function (arg_1,arg_2) {
        var myChart = echarts.init(document.getElementById('grah_03'));
        // 指定图表的配置项和数据
        var option = {
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'left',
                data:arg_1
            },
            series: [
                {
                    // name:'访问来源',
                    type:'pie',
                    radius: ['50%', '70%'],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '30',
                                fontWeight: 'bold'
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:arg_2
                }
            ]
        };

        myChart.setOption(option);
    };

    //划分获取的数据
    var divisionData = function (data) {
        temp = {};
        arg_1 = [];
        arg_2 = [];
        for( i in data) {
            temp = {};
            temp['name'] = data[i].url;
            temp['value'] = data[i].count;
            arg_2.push(temp);
            arg_1.push(data[i].url);
            if( i == 5)
                break;
        }
        result = {};
        result['arg_1'] =arg_1;
        result['arg_2'] =arg_2;
        return result;
    };

    //调度api获得数据
    var getData = function (url) {
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            async: false
            ,
            success: function (data) {
                // data = [{"url": "buaa-css-web", "count": 16743, "order": 1}, {"url": "~wanglili", "count": 59, "order": 2}];
                arg = divisionData(data);
                setPicture_03(result.arg_1,result.arg_2);
                $scope.data = data;


            },
            error: function () {
                console.log('api_error');
            }
        });
    };

    //获得本api的数据
    var getApi = function (target) {
        $http.get(target).then(function (response) {
            var urls = response.data;
            self.url = urls['api_03'];
            for( var i = 0 ; i < 25000000; i++)
            {
                a= 1;
                b= 2;
                a+b;
            }
            getData(self.url);
        });
    };

    //监听函数
    $scope.$watch('aaa', function (newValue, oldValue) {
        if( $rootScope.aaa !=0) {
            getApi(target);
        }
    });

    //设置字符串处理系统
    $scope.judgeStr = function (str,len) {
        if( str.length > len )
            return str.slice(0,len)+'...';
        return str
    };


});

ngApp
    .controller('ButtonController', function ($scope,$http,$rootScope) {

        $rootScope.aaa = 0;

        $rootScope.showSign = 0;
        /*变量集合*/
        $scope.button_start_action = function () {
            $rootScope.aaa = 0;
        };
        $scope.button_analys_action = function () {
            $rootScope.aaa = $rootScope.aaa +1;
            $rootScope.showSign = 1;
        };
    });

