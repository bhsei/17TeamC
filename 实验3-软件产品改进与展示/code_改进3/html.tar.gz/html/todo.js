ngApp = angular.module('todoApp', []);

ngApp
    .controller('PictureController01', function ($scope,$http,$rootScope) {
    /*变量集合*/
    var target = 'config.json';
    self.url = "";
    $scope.mapArray = ['一','二','三','四','五','六','七','八','九','十'];

    /*方法集合*/
    //数据格式处理
    var dealData = function (data) {
        order =[];
        co = [];
        for( i in data) {
            order.push(data[i].order);
            co.push(data[i].count);
        }
        result= {};
        result['order'] = order;
        result['co'] = co;
        return result;
    };

    //设置图片属性
    var setPicture_01 = function ( a,b ) {
        var myChart = echarts.init(document.getElementById('grah_01'));
        // 指定图表的配置项和数据

        var option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                },
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'value',
                boundaryGap: [0, 0.01]
            },
            yAxis: {
                type: 'category',
                data: a
            },
            series: [
                {
                    type: 'bar',
                    data: b
                }
            ]
        };

        myChart.setOption(option);
    };

    //调度api获得处理的数据
    var getData = function (url) {
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            async: false
            ,
            success: function (data) {
                year =[];
                count = [];
                for( i in data) {

                    year.push(i);
                    count.push(data[i]);
                }
                setPicture_01(year,count)

            },
            error: function () {

            }
        });
    };

    //获得本api的数据
    var getApi = function (target) {
        $http.get(target).then(function (response) {
            var urls = response.data;
            self.url = urls['api_01'];
            console.log(self.url);
        });
    };

    //监听按钮
    $scope.$watch('aaa', function (newValue, oldValue) {
        if( $rootScope.aaa !=0) {
            data = [{"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?secondSelId=f60d4e30-2c16-4863-8f85-f7c80160cc32&firstSelId=447bed87-d3c8-471c-8573-d6c3108604b7&language=0&allTeacherNaviName=", "count": 134.0, "order": 1}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?thirdSelId=6c270349-e69d-4d63-b8ce-93d062934955&firstSelId=447bed87-d3c8-471c-8573-d6c3108604b7&thirdNavName=%E5%85%AC%E5%BC%80%E8%AF%BE%E7%9B%AE%E5%BD%95&secondNavName=%E4%BC%98%E8%B4%A8%E5%85%AC%E5%BC%80%E8%AF%BE&language=0&allTeacherNaviName=", "count": 120.0, "order": 2}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=447bed87-d3c8-471c-8573-d6c3108604b7&thirdSelId=6c270349-e69d-4d63-b8ce-93d062934955&thirdNavName=%E5%85%AC%E5%BC%80%E8%AF%BE%E7%9B%AE%E5%BD%95&secondNavName=%E4%BC%98%E8%B4%A8%E5%85%AC%E5%BC%80%E8%AF%BE&language=0&allTeacherNaviName=", "count": 120.0, "order": 3}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?secondSelId=6a17c18f-faff-43ea-ba75-0b0f180ac5e1&firstSelId=447bed87-d3c8-471c-8573-d6c3108604b7&language=0&allTeacherNaviName=", "count": 119.0, "order": 4}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action;jsessionid=bca62f5b6a51a604a4e87ae04f03?firstSelId=a3eca420-9af6-4d86-ba79-d47efd388cd3&updateSelFirstNav=true&language=0", "count": 86.0, "order": 5}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=a3eca420-9af6-4d86-ba79-d47efd388cd3&updateSelFirstNav=true&language=0", "count": 86.0, "order": 6}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?secondSelId=c558f441-b606-4283-904f-ab77d220a4b6&firstSelId=a3eca420-9af6-4d86-ba79-d47efd388cd3&language=0&allTeacherNaviName=", "count": 86.0, "order": 7}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action;jsessionid=bca62f5b6a51a604a4e87ae04f03?firstSelId=CARD_TMPL_OF_FIRST_NAVI_CN&updateSelFirstNav=true&language=0", "count": 56.0, "order": 8}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=CARD_TMPL_OF_FIRST_NAVI_CN&updateSelFirstNav=true&language=0", "count": 56.0, "order": 9}, {"url": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?secondSelId=CARD_TMPL_OF_ALL_TEACHER_CN&firstSelId=CARD_TMPL_OF_FIRST_NAVI_CN&language=0&allTeacherNaviName=%E5%85%A8%E4%BD%93%E6%95%99%E5%B8%88", "count": 56.0, "order": 10}];
            result = dealData(data);
            $scope.data = data;
            setPicture_01(result.order,result.co);
        }
    });

    //判断字符串长度
    $scope.judgeStr = function (str,len) {
        if( str.length > len )
            return str.slice(0,len)+'...';
        return str
    };

    /*执行阶段*/
    //测试
    getApi(target);



});

ngApp
    .controller('PictureController02', function ($scope,$http,$rootScope) {

    /*变量集合*/
    var target = 'config.json';
    self.url = "";
    $scope.mapArray = ['一','二','三','四','五','六','七','八','九','十']

    /*方法集合*/
    //设置图片内容
    var setPicture_02 = function (arg_1,arg_2) {
        var myChart = echarts.init(document.getElementById('grah_02'));
        // 指定图表的配置项和数据
        var option = {
            color: ['#3398DB'],
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    data : arg_1,
                    axisTick: {
                        alignWithLabel: true
                    }
                }
            ],
            yAxis : [
                {

                    axisTick: {
                        alignWithLabel: true
                    }
                }
            ],
            series : [
                {
                    // name:'直接访问',
                    type:'bar',
                    barWidth: '40%',
                    // data:[1, 3, 2, 3, 4, 2, 1,3,3,2,3,2]
                    data:arg_2
                },

            ],
            label: {
                normal: {
                    show: true,
                    position: 'top',
                    formatter: '{c}'
                }
            },
            itemStyle: {
                normal: {

                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(17, 168,171, 1)'
                    }, {
                        offset: 1,
                        color: 'rgba(17, 168,171, 0.1)'
                    }]),
                    shadowColor: 'rgba(0, 0, 0, 0.1)',
                    shadowBlur: 10
                }
            }
        };

        myChart.setOption(option);
    };

    //划分获取的数据
    var divisionData = function (data) {
        arg_1 = [];
        arg_2 = [];
        for( i in data) {
            arg_2.push(data[i].order);
            arg_1.push(data[i].count);
        }
        result = {};
        result['arg_1'] =arg_1;
        result['arg_2'] =arg_2;
        return result;
    };

    //调度api获得数据
    var getData = function (url) {
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            async: false
            ,
            success: function (data) {

                setPicture_02(arg_1,arg_2)


            },
            error: function () {

            }
        });
    };

    //获得本api的数据
    var getApi = function (target) {
        $http.get(target).then(function (response) {
            var urls = response.data;
            self.url = urls['api_02'];
            console.log(self.url);
        });
    };

    //设置字符串处理系统
    $scope.judgeStr = function (str,len) {
        if( str.length > len )
            return str.slice(0,len)+'...';
        return str
    };

    $scope.$watch('aaa', function (newValue, oldValue) {
        if( $rootScope.aaa !=0) {
            data = [{"count": 772.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/initAction.action?language=1", "order": 1}, {"count": 768.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/initAction.action?language=0", "order": 2}, {"count": 668.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=86e2774f-d9eb-4dba-a704-0d7a234eaa3a&updateSelFirstNav=true&language=0", "order": 3}, {"count": 668.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=447bed87-d3c8-471c-8573-d6c3108604b7&updateSelFirstNav=true&language=0", "order": 4}, {"count": 668.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=a3eca420-9af6-4d86-ba79-d47efd388cd3&updateSelFirstNav=true&language=0", "order": 5}, {"count": 668.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=CARD_TMPL_OF_FIRST_NAVI_CN&updateSelFirstNav=true&language=0", "order": 6}, {"count": 668.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=95c3756d-5d3e-4b43-b8db-d73526e1e1c7&updateSelFirstNav=true&language=0", "order": 7}, {"count": 668.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=6e011b46-2c70-4f68-a633-ec51f42b4718&updateSelFirstNav=true&language=0", "order": 8}, {"count": 668.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=f72041e7-c66e-4fc4-b8f2-ae0797744edb&updateSelFirstNav=true&language=0", "order": 9}, {"count": 668.0, "target": "http://scse.buaa.edu.cn/buaa-css-web/navigationTemplateListAction.action?firstSelId=58b1eaf6-9094-4d43-9889-64eea86cf28b&updateSelFirstNav=true&language=0", "order": 10}];
            result = divisionData(data);
            console.log(result);
            $scope.data = data;
            setPicture_02(result.arg_2,result.arg_1);
        }
    });
    /*执行序列*/
    //测试
    getApi(target);


});

ngApp
    .controller('PictureController03', function ($scope,$http,$rootScope) {

    /*变量集合*/
    var target = 'config.json';
    self.url = "";

    /*方法集合*/
    //设置图片内容
    var setPicture_03 = function (arg_1,arg_2) {
        var myChart = echarts.init(document.getElementById('grah_03'));
        // 指定图表的配置项和数据
        var option = {
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'left',
                data:arg_1
            },
            series: [
                {
                    // name:'访问来源',
                    type:'pie',
                    radius: ['50%', '70%'],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '30',
                                fontWeight: 'bold'
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:arg_2
                }
            ]
        };

        myChart.setOption(option);
    };

    //划分获取的数据
    var divisionData = function (data) {
        temp = {};
        arg_1 = [];
        arg_2 = [];
        for( i in data) {
            temp = {};
            temp['name'] = data[i].url;
            temp['value'] = data[i].count;
            arg_2.push(temp);
            arg_1.push(data[i].url);
            if( i == 5)
                break;
        }
        result = {};
        result['arg_1'] =arg_1;
        result['arg_2'] =arg_2;
        return result;
    };

    //调度api获得数据
    var getData = function (url) {
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            async: false
            ,
            success: function (data) {
                // data = {'高':1,'低':1,'中':1};
                temp = {};
                arg_1 = [];
                arg_2 = [];
                for( item in data) {
                    temp = {};
                    temp['name'] = item;
                    temp['value'] = data[item];
                    arg_2.push(temp);
                    arg_1.push(item);
                }
                setPicture_02(arg_1,arg_2)


            },
            error: function () {

            }
        });
    };

    //获得本api的数据
    var getApi = function (target) {
        $http.get(target).then(function (response) {
            var urls = response.data;
            self.url = urls['api_02'];
            console.log(self.url);
        });
    };

    //监听函数
    $scope.$watch('aaa', function (newValue, oldValue) {
        if( $rootScope.aaa !=0) {

            data = [{"url": "buaa-css-web", "count": 16743, "order": 1}, {"url": "~wanglili", "count": 59, "order": 2}];
            arg = divisionData(data);
            setPicture_03(result.arg_1,result.arg_2);
            $scope.data = data;

        }
    });

    //设置字符串处理系统
    $scope.judgeStr = function (str,len) {
        if( str.length > len )
            return str.slice(0,len)+'...';
        return str
    };

    /*执行序列*/
    //测试
    getApi(target);

});

ngApp
    .controller('ButtonController', function ($scope,$http,$rootScope) {

        $rootScope.aaa = 0;

        $rootScope.showSign = 0;
        /*变量集合*/
        $scope.button_start_action = function () {
            $rootScope.aaa = 0;
        };
        $scope.button_analys_action = function () {
            $rootScope.aaa = $rootScope.aaa +1;
            $rootScope.showSign = 1;
        };
    });

